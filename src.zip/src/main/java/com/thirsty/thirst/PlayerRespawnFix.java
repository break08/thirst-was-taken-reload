package com.thirsty.thirst;

public class PlayerRespawnFix {
}