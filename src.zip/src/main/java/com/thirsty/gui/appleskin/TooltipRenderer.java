package com.thirsty.gui.appleskin;


import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.thirsty.gui.ThirstBarRenderer;
import com.thirsty.ThirstWasTaken;
import com.thirsty.misc.ThirstHelper;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.NotNull;
import squeek.appleskin.ModConfig;
import squeek.appleskin.api.food.FoodValues;
import squeek.appleskin.helpers.KeyHelper;

import java.util.Optional;

public class TooltipRenderer {
    public static void register(){
        TooltipComponentCallback.EVENT.register(data -> {
            if (data instanceof FoodTooltip food) {
                return new FoodTooltipRenderer(food);
            }
            return null;
        });
    }

    private static final ResourceLocation modIcons;
    private static final TextureOffsets normalBarTextureOffsets;
    private static final TextureOffsets rottenBarTextureOffsets;

    static {
        modIcons = ThirstWasTaken.asResource("textures/gui/appleskin_icons.png");
        normalBarTextureOffsets = new TextureOffsets();
        normalBarTextureOffsets.containerNegativeHunger = 43;
        normalBarTextureOffsets.containerExtraHunger = 133;
        normalBarTextureOffsets.containerNormalHunger = 16;
        normalBarTextureOffsets.containerPartialHunger = 124;
        normalBarTextureOffsets.containerMissingHunger = 34;
        normalBarTextureOffsets.shankMissingFull = 70;
        normalBarTextureOffsets.shankMissingPartial = normalBarTextureOffsets.shankMissingFull + 9;
        normalBarTextureOffsets.shankFull = 52;
        normalBarTextureOffsets.shankPartial = normalBarTextureOffsets.shankFull + 9;
        rottenBarTextureOffsets = new TextureOffsets();
        rottenBarTextureOffsets.containerNegativeHunger = normalBarTextureOffsets.containerNegativeHunger;
        rottenBarTextureOffsets.containerExtraHunger = normalBarTextureOffsets.containerExtraHunger;
        rottenBarTextureOffsets.containerNormalHunger = normalBarTextureOffsets.containerNormalHunger;
        rottenBarTextureOffsets.containerPartialHunger = normalBarTextureOffsets.containerPartialHunger;
        rottenBarTextureOffsets.containerMissingHunger = normalBarTextureOffsets.containerMissingHunger;
        rottenBarTextureOffsets.shankMissingFull = 106;
        rottenBarTextureOffsets.shankMissingPartial = rottenBarTextureOffsets.shankMissingFull + 9;
        rottenBarTextureOffsets.shankFull = 88;
        rottenBarTextureOffsets.shankPartial = rottenBarTextureOffsets.shankFull + 9;
    }

    static class TextureOffsets {
        int containerNegativeHunger;
        int containerExtraHunger;
        int containerNormalHunger;
        int containerPartialHunger;
        int containerMissingHunger;
        int shankMissingFull;
        int shankMissingPartial;
        int shankFull;
        int shankPartial;

        TextureOffsets() {
        }
    }

    public static boolean shouldShowTooltip(ItemStack hoveredStack) {
        if (hoveredStack.isEmpty()) {
            return false;
        } else {
            boolean shouldShowTooltip = ModConfig.INSTANCE.showFoodValuesInTooltip && KeyHelper.isShiftKeyDown() || ModConfig.INSTANCE.showFoodValuesInTooltipAlways;
            if (!shouldShowTooltip) {
                return false;
            } else {
                return ThirstHelper.itemRestoresThirst(hoveredStack);
            }
        }
    }

    public static class FoodTooltip implements TooltipComponent {
        private FoodValues defaultFood;
        private FoodValues modifiedFood;
        private final int biggestHunger;
        private final float biggestSaturationIncrement;
        private int hungerBars;
        private String hungerBarsText;
        private int saturationBars;
        private String saturationBarsText;
        private final ItemStack itemStack;

        FoodTooltip(ItemStack itemStack) {
            this.itemStack = itemStack;
            this.biggestHunger = ThirstHelper.getThirst(itemStack);
            this.biggestSaturationIncrement = ThirstHelper.getQuenched(itemStack);
            this.hungerBars = (int)Math.ceil((float)Math.abs(this.biggestHunger) / 2.0F);
            if (this.hungerBars > 10) {
                this.hungerBarsText = "x" + (this.biggestHunger < 0 ? -1 : 1) * this.hungerBars;
                this.hungerBars = 1;
            }

            this.saturationBars = (int)Math.ceil(Math.abs(this.biggestSaturationIncrement) / 2.0F);
            if (this.saturationBars > 10 || this.saturationBars == 0) {
                this.saturationBarsText = "x" + (this.biggestSaturationIncrement < 0.0F ? -1 : 1) * this.saturationBars;
                this.saturationBars = 1;
            }

        }

        boolean shouldRenderHungerBars() {
            return this.hungerBars > 0;
        }
    }

    static class FoodTooltipRenderer implements ClientTooltipComponent {
        private final FoodTooltip foodTooltip;

        FoodTooltipRenderer(FoodTooltip foodTooltip) {
            this.foodTooltip = foodTooltip;
        }

        public int getHeight() {
            return 20;
        }

        public int getWidth(@NotNull Font font) {
            int hungerBarsWidth = this.foodTooltip.hungerBars * 9;
            if (this.foodTooltip.hungerBarsText != null) {
                hungerBarsWidth += font.width(this.foodTooltip.hungerBarsText);
            }

            int saturationBarsWidth = this.foodTooltip.saturationBars * 7;
            if (this.foodTooltip.saturationBarsText != null) {
                saturationBarsWidth += font.width(this.foodTooltip.saturationBarsText);
            }

            return Math.max(hungerBarsWidth, saturationBarsWidth) + 2;
        }

        public void renderImage(@NotNull Font font, int x, int y, @NotNull GuiGraphics guiGraphics) {
            ItemStack itemStack = foodTooltip.itemStack;
            Minecraft mc = Minecraft.getInstance();
            if (!shouldShowTooltip(itemStack))
                return;

            Screen gui = mc.screen;
            if (gui == null)
                return;

            RenderSystem.enableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();

            int offsetX = x;
            int offsetY = y;

            int thirst = ThirstHelper.getThirst(itemStack);

            // Render from right to left so that the icons 'face' the right way
            offsetX += (foodTooltip.hungerBars - 1) * 9;

            ResourceLocation icons = ThirstBarRenderer.THIRST_ICONS;
            RenderSystem.setShaderTexture(0, icons);
            for (int i = 0; i < foodTooltip.hungerBars * 2; i += 2)
            {
                if (thirst == i + 1)
                    guiGraphics.blit(icons, offsetX, offsetY,0, 8, 0, 9, 9, 25, 9);
                else
                    guiGraphics.blit(icons, offsetX, offsetY,0, 16, 0, 9, 9, 25, 9);

                offsetX -= 9;
            }
            if (foodTooltip.hungerBarsText != null)
            {
                PoseStack poseStack = guiGraphics.pose();
                offsetX += 18;
                poseStack.pushPose();
                poseStack.translate(offsetX, offsetY, 0);
                poseStack.scale(0.75f, 0.75f, 0.75f);
                guiGraphics.drawCenteredString(font, foodTooltip.hungerBarsText, 2, 2, 0xFFAAAAAA);
                poseStack.popPose();
            }

            offsetX = x;
            offsetY += 10;

            float modifiedSaturationIncrement = ThirstHelper.getQuenched(itemStack);
            float absModifiedSaturationIncrement = Math.abs(modifiedSaturationIncrement);

            // Render from right to left so that the icons 'face' the right way
            offsetX += (foodTooltip.saturationBars - 1) * 7;

            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

            ResourceLocation appleskinIcons = modIcons;

            RenderSystem.setShaderTexture(0, appleskinIcons);
            for (int i = 0; i < foodTooltip.saturationBars * 2; i += 2)
            {
                float effectiveSaturationOfBar = (absModifiedSaturationIncrement - i) / 2f;

                boolean shouldBeFaded = absModifiedSaturationIncrement <= i;
                if (shouldBeFaded)
                    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, .5F);

                guiGraphics.blit(appleskinIcons, offsetX, offsetY, 0, effectiveSaturationOfBar >= 1 ? 21 : effectiveSaturationOfBar > 0.5 ? 14 : effectiveSaturationOfBar > 0.25 ? 7 : effectiveSaturationOfBar > 0 ? 0 : 28, modifiedSaturationIncrement >= 0 ? 27 : 34, 7, 7, 256, 256);

                if (shouldBeFaded)
                    RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

                offsetX -= 7;
            }
            if (foodTooltip.saturationBarsText != null)
            {
                offsetX += 14;
                PoseStack poseStack = guiGraphics.pose();
                poseStack.pushPose();
                poseStack.translate(offsetX, offsetY, 0);
                poseStack.scale(0.75f, 0.75f, 0.75f);
                guiGraphics.drawCenteredString(font, foodTooltip.saturationBarsText, 2, 1, 0xFFAAAAAA);
                poseStack.popPose();
            }

            RenderSystem.disableBlend();
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            RenderSystem.setShaderTexture(0,modIcons);

            // reset to drawHoveringText state
            RenderSystem.disableDepthTest();
        }
    }

    public static Optional<TooltipComponent> createTooltip(ItemStack stack) {
        if (!shouldShowTooltip(stack)) return Optional.empty();
        FoodTooltip tooltip = new FoodTooltip(stack);
        return tooltip.shouldRenderHungerBars() ? Optional.of(tooltip) : Optional.empty();
    }
}
